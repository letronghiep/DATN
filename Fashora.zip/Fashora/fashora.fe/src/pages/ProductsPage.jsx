import { Pagination } from "antd";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import { useSearchProductQuery } from "../apis/productsApi";
import ProductCard from "../components/product/product-card";

function ProductsPage() {
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [searchParams, setSearchParams] = useSearchParams();
  const filters = useSelector((state) => state.filter);

  
  const handlePageChange = (page) => {
    setCurrentPage(page);
    setSearchParams({ page, offset: limit });
  };

  useEffect(() => {
    const offset = Number(searchParams.get("offset")) || 10;
    const currentPage = Number(searchParams.get("page")) || 1;
    setLimit(Number(offset));
    setCurrentPage(Number(currentPage));
  }, [searchParams, filters]);

  const { data, isLoading } = useSearchProductQuery(
    {
      q: "",
      product_status: "published",
      limit: parseInt(limit),
      currentPage: parseInt(currentPage),
      sort: "ctime",
      product_price: filters.priceRange,
      size: filters.size,
      color: filters.color,
      product_category: filters.product_category || null,
    }
  );

  return (
    <div className="container mx-auto px-4 py-8">

      {isLoading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Đang tải sản phẩm...</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-2 md:gap-3">
            {data?.metadata?.data &&
              data?.metadata?.data.map((product) => (
                <div key={product._id} className="transform transition-transform duration-300 hover:scale-105">
                  <ProductCard
                    className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                    product={product}
                  />
                </div>
              ))}
          </div>

          {data?.metadata?.data && data?.metadata?.data.length > 0 && (
            <div className="mt-8">
              <Pagination
                className="flex justify-center"
                current={currentPage}
                onChange={handlePageChange}
                total={data?.metadata?.totalRows}
                pageSize={limit}
              />
            </div>
          )}

          {data?.metadata?.data && data?.metadata?.data.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-600">Không tìm thấy sản phẩm nào</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default ProductsPage;
