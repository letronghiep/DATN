import { axiosInstance } from "../../core/axiosInstance";

export async function getDiscountByShop({ q, discount_status }) {
  try {
    const res = await axiosInstance.get(
      `/discount?q=${q}&discount_status=${discount_status}`
    );
    const data = await res.data;
    return data;
  } catch (error) {
    console.log(error);
  }
}
