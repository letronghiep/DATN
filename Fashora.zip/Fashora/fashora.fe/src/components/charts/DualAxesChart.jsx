import Chart from "chart.js/auto";
import { useEffect, useRef } from "react";
function DualAxesChart({ dataChart, dataSetBar, dataSetLine, max, min }) {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: "top",
        labels: {
          usePointStyle: true,
          padding: 20,
          font: {
            size: 12,
            weight: "bold",
          },
        },
      },
      tooltip: {
        mode: "index",
        intersect: false,
        backgroundColor: "rgba(255, 255, 255, 0.9)",
        titleColor: "#333",
        bodyColor: "#666",
        borderColor: "#ddd",
        borderWidth: 1,
        padding: 10,
        callbacks: {
          label: function (context) {
            if (context.dataset.label === "Doanh thu") {
              return `${
                context.dataset.label
              }: ${context.raw.toLocaleString()} VND`;
            } else if (context.dataset.label === "Đơn hàng") {
              return `Số đơn hàng: ${context.raw.toLocaleString()}`;
            }
            return `${context.dataset.label}: ${context.raw}`;
          },
        },
      },
    },
    scales: {
      revenue: {
        type: "linear",
        position: "left",
        min: Math.floor(min),
        max: Math.ceil(max),
        grid: { drawOnChartArea: false },
        ticks: {
          callback: (value) =>
            Number.isInteger(value) ? value.toLocaleString() : null,
        },
      },

      orders: {
        type: "linear",
        position: "right",
        min: 0,
        max: Math.ceil(Math.max(...dataSetLine)) + 1,
        grid: { drawOnChartArea: false },
        ticks: {
          stepSize: 1,
          callback: (value) =>
            Number.isInteger(value) ? value.toLocaleString() : "",
          precision: 0,
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          autoSkip: false,
          maxRotation: 45,
          minRotation: 45,
          font: {
            size: 12,
          },
        },
      },
    },
  };
  useEffect(() => {
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    const myChartRef = chartRef.current.getContext("2d");

    chartInstance.current = new Chart(myChartRef, {
      type: "dualAxes",
      data: {
        labels: dataChart,
        datasets: [
          {
            label: "Doanh thu",
            data: dataSetBar,
            type: "bar",
            backgroundColor: "rgba(28, 143, 255, 0.4)",
            borderColor: "#1c8fff",
            borderWidth: 1,
            yAxisID: "revenue",
            order: 2,
            borderRadius: 4,
            barPercentage: 0.6,
          },
          {
            label: "Đơn hàng",
            data: dataSetLine,
            type: "line",
            backgroundColor: "rgba(246, 123, 43, 0.2)",
            borderColor: "#f67b2b",
            borderWidth: 4,
            pointBackgroundColor: "#f67b2b",
            pointBorderColor: "#fff",
            pointBorderWidth: 3,
            pointRadius: 6,
            pointHoverRadius: 8,
            tension: 0,
            order: 1,
            fill: true,
            fillColor: "rgba(246, 123, 43, 0.1)",
            shadowColor: "rgba(246, 123, 43, 0.5)",
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowOffsetY: 4,
            stepped: true,
            animation: {
              duration: 2000,
              easing: "easeInOutQuart",
              onProgress: function (animation) {
                const chart = animation.chart;
                const ctx = chart.ctx;
                const dataset = chart.data.datasets[1];
                const points = dataset.data;

                ctx.save();
                points.forEach((value, index) => {
                  if (value > 0) {
                    const meta = chart.getDatasetMeta(1);
                    const point = meta.data[index];
                    const x = point.x;
                    const y = point.y;

                    // Vẽ hiệu ứng sóng
                    ctx.beginPath();
                    ctx.arc(x, y, 8, 0, Math.PI * 2);
                    ctx.fillStyle = "rgba(246, 123, 43, 0.2)";
                    ctx.fill();

                    // Vẽ hiệu ứng nhấp nháy
                    if (animation.currentStep % 2 === 0) {
                      ctx.beginPath();
                      ctx.arc(x, y, 4, 0, Math.PI * 2);
                      ctx.fillStyle = "rgba(246, 123, 43, 0.6)";
                      ctx.fill();
                    }
                  }
                });
                ctx.restore();
              },
            },
          },
        ],
      },
      options: {
        ...options,
        animation: {
          duration: 2000,
          easing: "easeInOutQuart",
        },
        plugins: {
          ...options.plugins,
          legend: {
            ...options.plugins.legend,
            labels: {
              ...options.plugins.legend.labels,
              boxWidth: 15,
              boxHeight: 15,
            },
          },
        },
      },
    });
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [dataChart, dataSetBar, dataSetLine, max, min]);
  return (
    <div style={{ height: "300px", position: "relative" }}>
      <canvas id="myChart" ref={chartRef} />
    </div>
  );
}

export default DualAxesChart;
