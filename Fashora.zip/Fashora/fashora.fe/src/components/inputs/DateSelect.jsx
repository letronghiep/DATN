"use client";
import { DAYS, MONTH } from "~/constants";
import { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { useWatch } from "react-hook-form";
import SelectCustom from "./Select";

function DateSelect({ dataDate, onApply, disabled }) {
  const { control, watch, reset } = useForm({
    defaultValues: {
      day: "",
      month: "",
      year: "",
    },
    criteriaMode: "all",
  });
  const [day, month, year] = useWatch({
    control,
    name: ["day", "month", "year"],
  });

  // Generate year data
  const getYear = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    const startDate = currentYear - 100;
    for (let i = currentYear; i >= startDate; i--) {
      years.push({ id: i.toString(), label: i.toString() });
    }
    return years;
  };

  // Update form values when `dataDate` is provided
  useEffect(() => {
    if (dataDate) {
      const newData = new Date(dataDate);
      const day = newData.getDate().toString();
      const month = (newData.getMonth() + 1).toString();
      const year = newData.getFullYear().toString();
      reset({
        day,
        month: "Tháng " + month,
        year,
      });
    }
  }, [dataDate, reset]);

  // Watch for changes in form values
  // const selectedDate = watch(["day", "month", "year"]);
  const hasApplied = useRef(false);
  useEffect(() => {
    // if (selectedDate && selectedDate[0] && selectedDate[1] && selectedDate[2]) {
    //   const [day, month, year] = selectedDate;
    //   if (day && month && year) {
    //     onApply({ day, month, year });
    //   }
    // }
    const allSelected = !!day && !!month && !!year;

    if (allSelected && !hasApplied.current) {
      hasApplied.current = true;
      onApply({ day, month, year });
    }
  }, [day, month, year, onApply]);

  return (
    <div className="w-full gap-x-3 flex items-center">
      <SelectCustom
        name="day"
        control={control}
        data={DAYS}
        valueField="label"
        keyField="id"
        placeholder="Ngày"
        disabled={disabled}
      />
      <SelectCustom
        name="month"
        control={control}
        data={MONTH}
        valueField="label"
        keyField="id"
        placeholder="Tháng"
        disabled={disabled}
      />
      <SelectCustom
        name="year"
        control={control}
        data={getYear()}
        valueField="label"
        keyField="id"
        placeholder="Năm"
        disabled={disabled}
      />
    </div>
  );
}

export default DateSelect;
