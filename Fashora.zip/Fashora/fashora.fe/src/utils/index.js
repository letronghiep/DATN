export const TYPE_USER = {
  ADMIN: "admin",
  USER: "user",
  SHOP: "shop",
};
