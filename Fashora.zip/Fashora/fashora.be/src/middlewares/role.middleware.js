const AccessControl = require("accesscontrol");
module.exports = new AccessControl();
